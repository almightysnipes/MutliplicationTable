﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim line As String = ""

        For i = 1 To 10
            DataGridView1.Rows.Add()
            For j = 1 To 10
                line &= i * j & " "
                DataGridView1.Rows(i - 1).Cells(j - 1).Value = i * j
            Next
            ListBox1.Items.Add(line)
            line = ""
        Next



    End Sub
End Class
